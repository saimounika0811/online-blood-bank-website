<html>
<head>
<div class="image">
<img src="blood-connection-650.png" alt="blood-connection-650" width="1200" height="240">
</div>
<h1><marquee behavior="scroll" direction="left">LIVE LIFE AND GIVE LIFE......</marquee></h1>
<style>
h1 
{
text-align:center;
background color:black;
}
input[type=text]
{
background-color:white;
text-align:center;
}
h2
{
text-align:center;
}
div.image
{
text-align:center;
}
body
{ 
background-image:url("hands.jpg");
background-repeat:no-repeat;
background-size:1610px 1000px;
background-position:center bottom;
}
</style>
</head>
</style>
<body>
<h1>Blood bank and its importance</h1>
<p><font size="5">The software system is an online blood bank management system that helps in managing various blood bank operations effectively. The project consists of a central repository containing various blood deposits available along with associated details. 
These details include blood type, storage area and date of storage. 
These details help in maintaining and monitoring the blood deposits. The project is an online system that allows to check weather required blood deposits of a particular group are available in the blood bank. Moreover the system also has added features such as 
patient name and contacts, blood booking and even need foe certain blood group is 
posted on the website to find available donors for a blood emergency. 
This online system is developed on HTML and supported by an Sql database to store blood and user specific details.
<br><b>What is blood?</b><br>
One can almost say that blood is that magic potion which gives life to another person. Though we have made tremendous discoveries and inventions in Science we are not yet able to make the magic potion called Blood. Human blood has no substitute. Requirement of safe blood is increasing and regular voluntary blood donations are vital for blood transfusion services.
<br><b>Why Donate Blood ?</b><br>
Blood is the part of life that is given to those who need it by those who have the resource to satisfy the need. The love of fellow human and a desire to share something of oneself is what singles out a blood donor from the others. Emergencies occur every minute. For each patient requiring blood, it is an emergency and the patients could have set back if blood is not available.
<br><b>Who can donate blood?</b><br>
Donor should be between 18-55 years of age with a weight of 50 kg or above with pulse rate, body temperature and blood pressure should be normal. Both men and women can donate. There are only few conditions in which donors are permanently excluded. The donor with history of epilepsy, psychotic disorders, abnormal bleeding tendencies, severe asthma, cardiovascular disorders, malignancy are permanently unfit for blood donation. Donors suffering from disease like hepatitis, malaria, measles, mumps, and syphilis may donate blood after full recovery with 3-6 months gap. Also people who have undergone surgery, blood transfusion may safely donate blood after 6-12 mths for woman donors who are pregnant or lactating blood is not taken as their iron reserves are already on the lower side.
<br><b>How much blood can be taken?</b><br>
Our body has 5.5 ltr of blood of which only 350 ml - 450 ml of blood is taken depending upon weight of donor. Majority of healthy adults can tolerate withdrawal of one unit of blood. The withdrawn blood volume is restored within 24 hours and the hemoglobin and cell components are restored in 2 months. Therefore it is safe to donate blood every three months.
<br><b>Who Needs Blood ?</b><br>
Your blood helps more than one life at a time. Every 2 seconds someone needs blood. Accidents, premature babies, major surgeries require Whole blood, where your blood after testing is used directly. Trauma, Anemia, other surgeries requires only RBC, which is separated from your blood. The procedure of splitting blood components is called Cytapheresis. Similarly Platelets are used for Cancer patients undergoing Chemotherapy, Dengue fever, etc. Fresh frozen plasma is used for patients having massive Transfusions, Plasma is used for Burns and Cryoprecipitate is used for Hemophilia.</font></p></body>
</html>
