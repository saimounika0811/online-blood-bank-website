<html>
<head>
<div class="image">
<img src="blood-connection-650.png" alt="blood-connection-650" width="1200" height="240">
</div>
<ul>
<li><a href="contactus.php">contact us</a></li>
<li><a href="who.php">Who can/can't donate blood</a></li>
<li><a href="feedbackwithimage.php">feedback</a></li>
<li><a href="blood and its importance.php">Blood and its importance</a></li>
<li><a href="list.php">List of Blood banks</a></li>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<li style="float:right"><a href="registerwithimage.php" >register</a></li>
</ul>

<h1><marquee behavior="scroll" direction="left">LIVE LIFE AND GIVE LIFE......</marquee></h1>
<style>
h1 
{
text-align:center;
background color:black;
}
input[type=text]
{
background-color:white;
text-align:center;
}
h2
{
color:white;
text-align:center;
text-decoration:none;
}
body
{ 
background-image:url("blood-donation.jpg");
background-repeat:no-repeat;
background-size:1510px 900px;
background-position:center bottom;
}
h3
{
text-align:right;
}
div.image
{
text-align:center;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color:#901A0E ;

}

li {
    float: left;
}

li a,.dropbtn {
    display: block;
    color: white;
    text-align: center;
    padding: 7px 16px;
    text-decoration: none;
}

li a:hover,.dropbtn:hover.dropbtn {
    background-color:#901A0E;
    color:yellow;
}
li.dropbtn{
    display:inline;
}
.dropbtn {
    background-color: #4CAF50;
    color: white;
    font-size: 16px;
    border: none;
    cursor: pointer;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color:#901A0E;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content a {
    color:white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
</head>
<body>

<h2><b><a href="adminloginwithimage.php">ADMIN LOGIN</a></b></h2>
<h2><b><a href="donorloginwithimage.php">DONOR LOGIN</a></b></h2>
<h2><b><a href="recepientloginwithimage.php">RECEPIENT LOGIN</a></b></h2>
</body>
</html>