<!DOCTYPE html>
<html>
<div class="image">
<img src="blood-connection-650.png" alt="blood-connection-650" width="1200" height="240">
</div>
<h1><marquee behavior="scroll" direction="left">LIVE LIFE AND GIVE LIFE......</marquee></h1>
<style>
h1 
{
text-align:center;
background color:black;
}
input[type=text]
{
background-color:white;
text-align:center;
}
table,th,td
{
text-align:center;
font-size:20px;
font-weight:bold;
}
td.center
{
text.align:center;
}
h2
{
text-align:center;
}
div.image
{
text-align:center;
}
body
{ 
background-image:url("hands.jpg");
background-repeat:no-repeat;
background-size:1610px 800px;
background-position:center bottom;
}
</style>
</head>
</head>
<body>
  <h1>District wise Blood banks</h1><br><br>

  <table width="1000">
   
    <thead>
      <tr class="w3-red">
        <th>S.no</th>
        <th>District</th>
        <th>Blood Bank</th>
      </tr>
    </thead>
    <tr>
      <td><b>1</b></td>
      <td>SHIMLA</td>
      <td>9418091918-IGMC SHIMILA</td>
    </tr>
    <tr>
      <td>2</td>
      <td>KANGRA</td>
      <td>9418135296-BLOOD BANK RPGMC TANDA</td>
    </tr>
    <tr>
      <td>3</td>
      <td>UNA</td>
      <td>9440237000-BLOOD BANK KULLU</td>
    </tr>
<tr>
      <td>4</td>
      <td>MANDI</td>
      <td>9440466746-BLOOD BANK MANDI</td>
    </tr>
<tr>
      <td>5</td>
      <td>SOLAN</td>
      <td>9790765431-BLOOD BANK SOLAN</td>
    </tr>
<tr>
      <td>6</td>
      <td>SIRMAUR</td>
      <td>8296293929-BLOOD BANK NAHAN</td>
    </tr>
<tr>
      <td>7</td>
      <td>BILLASPUT</td>
      <td>9418145553-BLOOD BANK BILLASPUR</td>
    </tr>
<tr>
      <td>8</td>
      <td>CHAMBRA</td>
      <td>9418452698-BLOOD BANK CHAMBRA</td>
    </tr>
<tr>
      <td>9</td>
      <td>HAMIRPUR</td>
      <td>9949085643-BLOOD BANK HAMIRPUR</td>
    </tr>
  </table>
</div>

</body>
</html>

