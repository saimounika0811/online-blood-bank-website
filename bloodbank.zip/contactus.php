<html>
<head>
<div class="image">

<img src="blood-connection-650.png" alt="blood-connection-650" width="1200" height="240">

</div>
<style>
body
{ 
background-image:url("hands.jpg");
background-repeat:no-repeat;
background-size:1510px 700px;
background-position:center bottom;
}
div.image
{
text-align:center;
}

</style>
</head>
<body>
<h1>CONTACT INFORMATION</h1>
<p>Name:Mounika</p>
<p>Address:VIT university,Kelambakkam road,Vandalur,Chennai</p>
<p>State:Tamil Nadu</p>
<p>phone number:9490856436</p>
<p>Name:Phani Deepthi</p>
<p>Address:VIT university,chennai road,vellore</p>
<p>State:Tamil Nadu</p>
<p>phone number:9440237000</p>
</body>
</html>



