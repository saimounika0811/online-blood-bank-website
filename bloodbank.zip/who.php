<html>
<head>

<div class="image">
<img src="blood-connection-650.png" alt="blood-connection-650" width="1200" height="240">
</div>
<h1><marquee behavior="scroll" direction="left">LIVE LIFE AND GIVE LIFE......</marquee></h1>
<style>
h1 
{
text-align:center;
background color:black;
}
input[type=text]
{
background-color:white;
text-align:center;
}
h2
{
text-align:center;
}
div.image
{
text-align:center;
}
body
{ 
background-image:url("hands.jpg");
background-repeat:no-repeat;
background-size:1610px 1000px;
background-position:center bottom;
}
</style>
</head>
<body>
<h1>Who can/can't donate blood</h1>
<p>
<b> <h2>Who can donate blood</h2><b><br>
<b>Let others benefit from your good health. Do donate blood if ...<b>
<ul>
<li>You are between age group of 18-65 years.</li>
<li>Your weight is 45 kgs or more.</li>
<li>Your haemoglobin is 12.5 gm% minimum.</li>
<li>Your last blood donation was 3 months earlier.</li>
<li>You are healthy and have not suffered from malaria, typhoid or other transmissible disease in the recent past.</li>
<b>There are many, many people who meet these parameters of health and fitness!<b>
Do abide by our rules - be truthful about your health status!
We ensure the health of blood, before we take it, as well as after it is collected. Firstly, the donor is expected to be honest about his or her health history and current condition. Secondly, collected blood is tested for venereal diseases, hepatitis B & C and AIDS. You have to be healthy to give 'safe blood'
<b><h2> Who can't donate blood</h2><b><br>
<b>Do not donate blood if you have any of these conditions...<b>
<li>cold / fever in the past 1 week.</li>
<li>under treatment with antibiotics or any other medication.</li>
<li>cardiac problems, hypertension, epilepsy, diabetes (on insulin therapy), history of cancer,chronic kidney or liver disease, bleeding tendencies, venereal disease etc.
major surgery in the last 6 months.</li>
<li>vaccination in the last 24 hours.</li>
<li>had a miscarriage in the last 6 months or have been pregnant / lactating in the last one year.
had fainting attacks during last donation.</li>
<li>have regularly received treatment with blood products.</li>
<li>shared a needle to inject drugs/ have history of drug addiction.</li>
<li>had sexual relations with different partners or with a high risk individual.</li>
been tested positive for antibodies to HIV.
<li>Pregnancy And Menstrual Cycle</li>
<li>Females should not donate blood during pregnancy.</li>
<li>They can donate after 6 weeks following a normal delivery and when they are not breast feeding.</li>
<li>Females should not donate blood if they are having heavy menstrual flow or menstrual cramps.</li>
</ul>

</body>
</html>